#ifndef THROTTLE_CONTROLLER_H
#define THROTTLE_CONTROLLER_H

#include <stdint.h>
#include "esp_log.h"

/**
 * @brief 限流策略枚举
 */
typedef enum {
    THROTTLE_STRATEGY_TIME_BASED = 0,    // 基于时间间隔
    THROTTLE_STRATEGY_COUNT_BASED,       // 基于计数限制
    THROTTLE_STRATEGY_ADAPTIVE          // 自适应限流
} throttle_strategy_t;

/**
 * @brief 限流配置结构体
 */
typedef struct {
    uint32_t min_interval_ms;           // 最小时间间隔(毫秒)
    uint16_t max_count_per_second;      // 每秒最大次数
    uint16_t max_count_per_minute;      // 每分钟最大次数
    throttle_strategy_t strategy;       // 限流策略
    bool enable_burst;                  // 是否允许突发
    uint16_t burst_size;               // 突发大小
} throttle_config_t;

/**
 * @brief 限流统计信息
 */
typedef struct {
    uint32_t total_requests;           // 总请求数
    uint32_t accepted_requests;        // 通过的请求数
    uint32_t rejected_requests;        // 拒绝的请求数
    uint32_t last_accept_time;         // 最后通过时间
    uint32_t last_reject_time;         // 最后拒绝时间
    float current_rate;                // 当前速率(请求/秒)
} throttle_stats_t;

/**
 * @brief 消息限流控制器类
 * 
 * 基于v1.0的ThrottleController实现，提供多种限流策略：
 * 1. 时间间隔限流
 * 2. 计数限流 
 * 3. 自适应限流
 */
class ThrottleController {
public:
    /**
     * @brief 构造函数
     * @param config 限流配置
     */
    ThrottleController(const throttle_config_t& config);
    
    /**
     * @brief 默认构造函数（使用默认配置）
     */
    ThrottleController();
    
    /**
     * @brief 析构函数
     */
    ~ThrottleController();
    
    /**
     * @brief 检查是否允许通过并更新状态
     * @param current_time 当前时间戳(毫秒)
     * @return true 允许通过, false 被限流
     */
    bool check_and_update(uint32_t current_time);
    
    /**
     * @brief 检查是否允许通过并更新状态（使用系统时间）
     * @return true 允许通过, false 被限流
     */
    bool check_and_update();
    
    /**
     * @brief 检查是否允许通过并更新状态（带自定义参数）
     * @param current_time 当前时间戳(毫秒)
     * @param min_interval 最小间隔(毫秒)
     * @param max_per_second 每秒最大次数
     * @return true 允许通过, false 被限流
     */
    bool check_and_update(uint32_t current_time, uint32_t min_interval, uint16_t max_per_second);
    
    /**
     * @brief 重置限流器状态
     */
    void reset();
    
    /**
     * @brief 更新配置
     * @param config 新的限流配置
     */
    void update_config(const throttle_config_t& config);
    
    /**
     * @brief 获取统计信息
     * @return 限流统计信息
     */
    throttle_stats_t get_stats() const;
    
    /**
     * @brief 获取当前配置
     * @return 当前限流配置
     */
    throttle_config_t get_config() const;
    
    /**
     * @brief 设置调试模式
     * @param enable 是否启用调试日志
     */
    void set_debug_mode(bool enable);
    
    /**
     * @brief 强制允许下一次请求（紧急情况使用）
     */
    void force_allow_next();

private:
    throttle_config_t config_;         // 限流配置
    throttle_stats_t stats_;           // 统计信息
    
    // 时间间隔限流相关
    uint32_t last_time_;               // 上次通过时间
    
    // 计数限流相关
    uint16_t count_per_second_;        // 当前秒内计数
    uint16_t count_per_minute_;        // 当前分钟内计数
    uint32_t last_second_;             // 上一秒时间戳
    uint32_t last_minute_;             // 上一分钟时间戳
    
    // 突发控制相关
    uint16_t burst_count_;             // 当前突发计数
    uint32_t burst_reset_time_;        // 突发重置时间
    
    // 自适应限流相关
    uint32_t adaptive_window_start_;   // 自适应窗口开始时间
    uint16_t adaptive_window_count_;   // 自适应窗口内计数
    
    // 调试相关
    bool debug_mode_;                  // 调试模式
    bool force_allow_;                 // 强制允许标志
    
    static const char* TAG;
    
    /**
     * @brief 检查时间间隔限流
     * @param current_time 当前时间
     * @return true 允许通过, false 被限流
     */
    bool check_time_based(uint32_t current_time);
    
    /**
     * @brief 检查计数限流
     * @param current_time 当前时间
     * @return true 允许通过, false 被限流
     */
    bool check_count_based(uint32_t current_time);
    
    /**
     * @brief 检查自适应限流
     * @param current_time 当前时间
     * @return true 允许通过, false 被限流
     */
    bool check_adaptive(uint32_t current_time);
    
    /**
     * @brief 更新统计信息
     * @param accepted 是否被接受
     * @param current_time 当前时间
     */
    void update_stats(bool accepted, uint32_t current_time);
    
    /**
     * @brief 计算当前速率
     * @param current_time 当前时间
     */
    void calculate_current_rate(uint32_t current_time);
};

// 预定义的限流配置
namespace ThrottleConfigs {
    // MQTT消息限流配置
    extern const throttle_config_t MQTT_GLOBAL;      // 全局MQTT限流
    extern const throttle_config_t MQTT_PROPERTY;    // 属性消息限流
    extern const throttle_config_t MQTT_EVENT;       // 事件消息限流
    extern const throttle_config_t MQTT_SERVICE;     // 服务调用限流
    
    // 系统级限流配置
    extern const throttle_config_t SYSTEM_CRITICAL;  // 系统关键操作限流
    extern const throttle_config_t NETWORK_REQUEST;  // 网络请求限流
    extern const throttle_config_t LOG_OUTPUT;       // 日志输出限流
}

#endif // THROTTLE_CONTROLLER_H 