#include "throttle_controller.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_system.h"

const char* ThrottleController::TAG = "ThrottleController";

// 预定义的限流配置
namespace ThrottleConfigs {
    // MQTT消息限流配置（基于v1.0的工业级配置）
    const throttle_config_t MQTT_GLOBAL = {
        .min_interval_ms = 80,           // 80ms最小间隔，提升数据实时性
        .max_count_per_second = 12,      // 12条/秒，满足工业实时需求
        .max_count_per_minute = 600,     // 10条/分钟限制
        .strategy = THROTTLE_STRATEGY_COUNT_BASED,
        .enable_burst = true,
        .burst_size = 3
    };
    
    const throttle_config_t MQTT_PROPERTY = {
        .min_interval_ms = 150,          // 150ms间隔，平衡性能和稳定性
        .max_count_per_second = 5,       // 5条/秒，改善响应性
        .max_count_per_minute = 240,     // 4条/分钟
        .strategy = THROTTLE_STRATEGY_TIME_BASED,
        .enable_burst = true,
        .burst_size = 2
    };
    
    const throttle_config_t MQTT_EVENT = {
        .min_interval_ms = 1000,         // 1秒间隔
        .max_count_per_second = 2,       // 2条/秒
        .max_count_per_minute = 60,      // 1条/分钟
        .strategy = THROTTLE_STRATEGY_TIME_BASED,
        .enable_burst = false,
        .burst_size = 0
    };
    
    const throttle_config_t MQTT_SERVICE = {
        .min_interval_ms = 400,          // 400ms间隔，服务调用适度放宽
        .max_count_per_second = 3,       // 3次/秒，提升工业应用响应性
        .max_count_per_minute = 120,     // 2次/分钟
        .strategy = THROTTLE_STRATEGY_COUNT_BASED,
        .enable_burst = true,
        .burst_size = 1
    };
    
    const throttle_config_t SYSTEM_CRITICAL = {
        .min_interval_ms = 50,           // 50ms间隔
        .max_count_per_second = 20,      // 20次/秒
        .max_count_per_minute = 600,     // 10次/分钟
        .strategy = THROTTLE_STRATEGY_ADAPTIVE,
        .enable_burst = true,
        .burst_size = 5
    };
    
    const throttle_config_t NETWORK_REQUEST = {
        .min_interval_ms = 200,          // 200ms间隔
        .max_count_per_second = 5,       // 5次/秒
        .max_count_per_minute = 180,     // 3次/分钟
        .strategy = THROTTLE_STRATEGY_TIME_BASED,
        .enable_burst = false,
        .burst_size = 0
    };
    
    const throttle_config_t LOG_OUTPUT = {
        .min_interval_ms = 10,           // 10ms间隔
        .max_count_per_second = 50,      // 50条/秒
        .max_count_per_minute = 1800,    // 30条/分钟
        .strategy = THROTTLE_STRATEGY_COUNT_BASED,
        .enable_burst = true,
        .burst_size = 10
    };
}

ThrottleController::ThrottleController(const throttle_config_t& config) 
    : config_(config), last_time_(0), count_per_second_(0), count_per_minute_(0),
      last_second_(0), last_minute_(0), burst_count_(0), burst_reset_time_(0),
      adaptive_window_start_(0), adaptive_window_count_(0), debug_mode_(false), force_allow_(false) {
    
    // 初始化统计信息
    stats_.total_requests = 0;
    stats_.accepted_requests = 0;
    stats_.rejected_requests = 0;
    stats_.last_accept_time = 0;
    stats_.last_reject_time = 0;
    stats_.current_rate = 0.0f;
    
    ESP_LOGD(TAG, "限流控制器初始化: 策略=%d, 最小间隔=%lu ms, 最大速率=%d/s", 
             config_.strategy, config_.min_interval_ms, config_.max_count_per_second);
}

ThrottleController::ThrottleController() : ThrottleController(ThrottleConfigs::MQTT_GLOBAL) {
    ESP_LOGD(TAG, "使用默认MQTT全局限流配置初始化");
}

ThrottleController::~ThrottleController() {
    if (debug_mode_) {
        ESP_LOGI(TAG, "限流控制器销毁: 总请求=%lu, 通过=%lu, 拒绝=%lu, 通过率=%.2f%%",
                 stats_.total_requests, stats_.accepted_requests, stats_.rejected_requests,
                 stats_.total_requests > 0 ? (float)stats_.accepted_requests * 100.0f / stats_.total_requests : 0.0f);
    }
}

bool ThrottleController::check_and_update(uint32_t current_time) {
    // 强制允许检查
    if (force_allow_) {
        force_allow_ = false;
        update_stats(true, current_time);
        ESP_LOGD(TAG, "强制允许请求通过");
        return true;
    }
    
    bool result = false;
    
    switch (config_.strategy) {
        case THROTTLE_STRATEGY_TIME_BASED:
            result = check_time_based(current_time);
            break;
        case THROTTLE_STRATEGY_COUNT_BASED:
            result = check_count_based(current_time);
            break;
        case THROTTLE_STRATEGY_ADAPTIVE:
            result = check_adaptive(current_time);
            break;
        default:
            result = check_time_based(current_time);
            break;
    }
    
    update_stats(result, current_time);
    calculate_current_rate(current_time);
    
    if (debug_mode_) {
        if (result) {
            ESP_LOGD(TAG, "请求通过: 总=%lu, 通过=%lu, 当前速率=%.2f/s",
                     stats_.total_requests, stats_.accepted_requests, stats_.current_rate);
        } else {
            ESP_LOGD(TAG, "请求被限流: 总=%lu, 拒绝=%lu, 当前速率=%.2f/s",
                     stats_.total_requests, stats_.rejected_requests, stats_.current_rate);
        }
    }
    
    return result;
}

bool ThrottleController::check_and_update() {
    return check_and_update(pdTICKS_TO_MS(xTaskGetTickCount()));
}

bool ThrottleController::check_and_update(uint32_t current_time, uint32_t min_interval, uint16_t max_per_second) {
    // 临时修改配置进行检查
    throttle_config_t temp_config = config_;
    config_.min_interval_ms = min_interval;
    config_.max_count_per_second = max_per_second;
    config_.strategy = THROTTLE_STRATEGY_TIME_BASED;
    
    bool result = check_and_update(current_time);
    
    // 恢复原配置
    config_ = temp_config;
    
    return result;
}

bool ThrottleController::check_time_based(uint32_t current_time) {
    // 检查时间间隔
    if (current_time - last_time_ < config_.min_interval_ms) {
        return false;
    }
    
    // 检查突发控制
    if (config_.enable_burst) {
        uint32_t burst_window = 1000; // 1秒突发窗口
        if (current_time - burst_reset_time_ > burst_window) {
            burst_count_ = 0;
            burst_reset_time_ = current_time;
        }
        
        if (burst_count_ >= config_.burst_size) {
            return false;
        }
        
        burst_count_++;
    }
    
    last_time_ = current_time;
    return true;
}

bool ThrottleController::check_count_based(uint32_t current_time) {
    uint32_t current_second = current_time / 1000;
    uint32_t current_minute = current_time / 60000;
    
    // 重置秒计数器
    if (current_second != last_second_) {
        count_per_second_ = 0;
        last_second_ = current_second;
    }
    
    // 重置分钟计数器
    if (current_minute != last_minute_) {
        count_per_minute_ = 0;
        last_minute_ = current_minute;
    }
    
    // 检查秒级限制
    if (count_per_second_ >= config_.max_count_per_second) {
        return false;
    }
    
    // 检查分钟级限制
    if (count_per_minute_ >= config_.max_count_per_minute) {
        return false;
    }
    
    // 检查最小时间间隔
    if (current_time - last_time_ < config_.min_interval_ms) {
        return false;
    }
    
    // 通过检查，更新计数器
    count_per_second_++;
    count_per_minute_++;
    last_time_ = current_time;
    
    return true;
}

bool ThrottleController::check_adaptive(uint32_t current_time) {
    const uint32_t ADAPTIVE_WINDOW_MS = 5000; // 5秒自适应窗口
    
    // 重置自适应窗口
    if (current_time - adaptive_window_start_ > ADAPTIVE_WINDOW_MS) {
        adaptive_window_start_ = current_time;
        adaptive_window_count_ = 0;
    }
    
    // 计算动态限制
    uint32_t elapsed = current_time - adaptive_window_start_;
    uint16_t expected_max = (config_.max_count_per_second * elapsed) / 1000;
    
    if (adaptive_window_count_ >= expected_max) {
        return false;
    }
    
    // 基本时间间隔检查
    if (current_time - last_time_ < config_.min_interval_ms) {
        return false;
    }
    
    adaptive_window_count_++;
    last_time_ = current_time;
    
    return true;
}

void ThrottleController::update_stats(bool accepted, uint32_t current_time) {
    stats_.total_requests++;
    
    if (accepted) {
        stats_.accepted_requests++;
        stats_.last_accept_time = current_time;
    } else {
        stats_.rejected_requests++;
        stats_.last_reject_time = current_time;
    }
}

void ThrottleController::calculate_current_rate(uint32_t current_time) {
    const uint32_t RATE_WINDOW_MS = 10000; // 10秒窗口计算速率
    
    static uint32_t rate_window_start = 0;
    static uint32_t rate_window_count = 0;
    
    if (rate_window_start == 0) {
        rate_window_start = current_time;
    }
    
    if (current_time - rate_window_start > RATE_WINDOW_MS) {
        stats_.current_rate = (float)rate_window_count * 1000.0f / RATE_WINDOW_MS;
        rate_window_start = current_time;
        rate_window_count = 0;
    } else {
        rate_window_count++;
    }
}

void ThrottleController::reset() {
    last_time_ = 0;
    count_per_second_ = 0;
    count_per_minute_ = 0;
    last_second_ = 0;
    last_minute_ = 0;
    burst_count_ = 0;
    burst_reset_time_ = 0;
    adaptive_window_start_ = 0;
    adaptive_window_count_ = 0;
    force_allow_ = false;
    
    // 清除统计信息
    stats_.total_requests = 0;
    stats_.accepted_requests = 0;
    stats_.rejected_requests = 0;
    stats_.last_accept_time = 0;
    stats_.last_reject_time = 0;
    stats_.current_rate = 0.0f;
    
    ESP_LOGD(TAG, "限流控制器状态已重置");
}

void ThrottleController::update_config(const throttle_config_t& config) {
    config_ = config;
    reset(); // 重置状态以应用新配置
    
    ESP_LOGI(TAG, "限流配置已更新: 策略=%d, 最小间隔=%lu ms, 最大速率=%d/s", 
             config_.strategy, config_.min_interval_ms, config_.max_count_per_second);
}

throttle_stats_t ThrottleController::get_stats() const {
    return stats_;
}

throttle_config_t ThrottleController::get_config() const {
    return config_;
}

void ThrottleController::set_debug_mode(bool enable) {
    debug_mode_ = enable;
    ESP_LOGI(TAG, "调试模式: %s", enable ? "启用" : "禁用");
}

void ThrottleController::force_allow_next() {
    force_allow_ = true;
    ESP_LOGW(TAG, "下一次请求将被强制允许通过");
} 