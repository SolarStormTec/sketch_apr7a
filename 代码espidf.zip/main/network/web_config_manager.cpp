#include "web_config_manager.h"
#include "esp_mac.h"
#include "esp_chip_info.h"
#include "esp_system.h"
#include "smartjet_common.h"

const char* WebConfigManager::TAG = "WebConfigManager";

WebConfigManager::WebConfigManager() : server(nullptr), portal_active(false), secure_mode(false) {
    ESP_LOGI(TAG, "Web配网管理器初始化");
}

WebConfigManager::~WebConfigManager() {
    stopConfigPortal();
}

String WebConfigManager::generateAPName() {
    uint8_t mac[6];
    esp_read_mac(mac, ESP_MAC_WIFI_STA);
    char ap_name[32];
    snprintf(ap_name, sizeof(ap_name), "SmartJet_%02X%02X%02X", mac[3], mac[4], mac[5]);
    return String(ap_name);
}

bool WebConfigManager::startConfigPortal(uint32_t timeout_ms, bool secure_mode_enabled) {
    if (portal_active) {
        ESP_LOGW(TAG, "配网Portal已经在运行");
        return false;
    }
    
    secure_mode = secure_mode_enabled;
    ap_name = generateAPName();
    
    ESP_LOGI(TAG, "启动配网Portal: %s", ap_name.c_str());
    
    // 启动AP模式
    WiFi.mode(WIFI_AP);
    if (!WiFi.softAP(ap_name.c_str(), "config1234")) {
        ESP_LOGE(TAG, "无法启动AP热点");
        return false;
    }
    
    IPAddress ip = WiFi.softAPIP();
    ESP_LOGI(TAG, "AP IP地址: %s", ip.toString().c_str());
    
    // 创建Web服务器
    server = new WebServer(80);
    if (!server) {
        ESP_LOGE(TAG, "无法创建Web服务器");
        return false;
    }
    
    // 设置路由
    if (secure_mode) {
        server->on("/", HTTP_GET, [this]() { handleSecureRoot(); });
        server->on("/triset", HTTP_POST, [this]() { handleSecureSave(); });
    } else {
        server->on("/", HTTP_GET, [this]() { handleRoot(); });
        server->on("/save", HTTP_POST, [this]() { handleSave(); });
    }
    server->onNotFound([this]() { handleNotFound(); });
    
    server->begin();
    ESP_LOGI(TAG, "Web服务器已启动");
    
    portal_active = true;
    uint32_t start_time = millis();
    
    // 处理请求直到超时
    while (millis() - start_time < timeout_ms && portal_active) {
        server->handleClient();
        delay(10);
        
        // 定期喂狗
        if (esp_task_wdt_status(xTaskGetCurrentTaskHandle()) == ESP_OK) {
            esp_task_wdt_reset();
        }
    }
    
    stopConfigPortal();
    return true;
}

void WebConfigManager::stopConfigPortal() {
    if (!portal_active) return;
    
    portal_active = false;
    
    if (server) {
        server->stop();
        delete server;
        server = nullptr;
    }
    
    WiFi.softAPdisconnect(true);
    ESP_LOGI(TAG, "配网Portal已停止");
}

bool WebConfigManager::hasWiFiConfig() {
    Preferences prefs;
    prefs.begin("wifi", true);
    String ssid = prefs.getString("ssid", "");
    prefs.end();
    return !ssid.isEmpty();
}

bool WebConfigManager::loadWiFiConfig(String& ssid, String& password) {
    Preferences prefs;
    prefs.begin("wifi", true);
    ssid = prefs.getString("ssid", "");
    password = prefs.getString("password", "");
    prefs.end();
    
    ESP_LOGI(TAG, "加载WiFi配置: SSID=%s", ssid.c_str());
    return !ssid.isEmpty();
}

bool WebConfigManager::saveWiFiConfig(const String& ssid, const String& password) {
    Preferences prefs;
    prefs.begin("wifi", false);
    bool success = prefs.putString("ssid", ssid);
    success &= prefs.putString("password", password);
    prefs.end();
    
    if (success) {
        ESP_LOGI(TAG, "WiFi配置保存成功: SSID=%s", ssid.c_str());
    } else {
        ESP_LOGE(TAG, "WiFi配置保存失败");
    }
    
    return success;
}

bool WebConfigManager::hasDeviceConfig() {
    String product_id, device_name, device_key;
    return loadDeviceConfig(product_id, device_name, device_key) && 
           validateDeviceConfig(product_id, device_name, device_key);
}

bool WebConfigManager::loadDeviceConfig(String& product_id, String& device_name, String& device_key) {
    Preferences prefs;
    prefs.begin("device", true);
    product_id = prefs.getString("product_id", "");
    device_name = prefs.getString("device_name", "");
    device_key = prefs.getString("device_key", "");
    prefs.end();
    
    ESP_LOGI(TAG, "加载设备配置: ProductID=%s, DeviceName=%s", 
             product_id.c_str(), device_name.c_str());
    
    return !product_id.isEmpty() && !device_name.isEmpty() && !device_key.isEmpty();
}

bool WebConfigManager::saveDeviceConfig(const String& product_id, const String& device_name, const String& device_key) {
    Preferences prefs;
    prefs.begin("device", false);
    bool success = prefs.putString("product_id", product_id);
    success &= prefs.putString("device_name", device_name);
    success &= prefs.putString("device_key", device_key);
    prefs.end();
    
    if (success) {
        ESP_LOGI(TAG, "设备配置保存成功: ProductID=%s, DeviceName=%s", 
                 product_id.c_str(), device_name.c_str());
    } else {
        ESP_LOGE(TAG, "设备配置保存失败");
    }
    
    return success;
}

bool WebConfigManager::validateDeviceConfig(const String& product_id, const String& device_name, const String& device_key) {
    bool valid = (product_id.length() >= 4 && device_name.length() >= 2 && device_key.length() >= 16);
    
    if (!valid) {
        ESP_LOGW(TAG, "设备配置验证失败: ProductID长度=%d, DeviceName长度=%d, DeviceKey长度=%d", 
                 product_id.length(), device_name.length(), device_key.length());
    }
    
    return valid;
}

void WebConfigManager::handleRoot() {
    String html = generateWiFiConfigPage();
    server->send(200, "text/html; charset=UTF-8", html);
}

void WebConfigManager::handleSave() {
    String ssid = server->arg("ssid");
    String password = server->arg("pass");
    
    if (ssid.length() == 0) {
        String errorHtml = generateErrorPage("配置错误", "WiFi网络名称(SSID)不能为空，请重新输入。");
        server->send(400, "text/html; charset=UTF-8", errorHtml);
        return;
    }
    
    // 保存WiFi配置
    if (saveWiFiConfig(ssid, password)) {
        String successHtml = generateSuccessPage("配置成功！", "WiFi网络配置已保存，设备正在重启...");
        server->send(200, "text/html; charset=UTF-8", successHtml);
        
        delay(2000);  // 确保页面发送完成
        stopConfigPortal();
        delay(1000);
        esp_restart();
    } else {
        String errorHtml = generateErrorPage("保存失败", "无法保存WiFi配置，请重试。");
        server->send(500, "text/html; charset=UTF-8", errorHtml);
    }
}

void WebConfigManager::handleSecureRoot() {
    String html = generateSecureConfigPage();
    server->send(200, "text/html; charset=UTF-8", html);
}

void WebConfigManager::handleSecureSave() {
    String password = server->arg("secret");
    String product_id = server->arg("product_id");
    String device_name = server->arg("device_name");
    String device_key = server->arg("device_key");
    
    // 验证管理员密码
    if (password != admin_password) {
        String errorHtml = generateErrorPage("密码错误", "管理员密码不正确，请重新输入。");
        server->send(401, "text/html; charset=UTF-8", errorHtml);
        return;
    }
    
    // 验证三元组配置
    if (!validateDeviceConfig(product_id, device_name, device_key)) {
        String errorHtml = generateErrorPage("三元组配置错误", 
            "设备三元组信息不符合要求：<br>"
            "• 产品ID长度必须至少4位<br>"
            "• 设备名称长度必须至少2位<br>"
            "• 设备密钥长度必须至少16位");
        server->send(400, "text/html; charset=UTF-8", errorHtml);
        return;
    }
    
    // 保存设备配置
    if (saveDeviceConfig(product_id, device_name, device_key)) {
        String successHtml = generateSuccessPage("安全配置成功！", 
            "设备三元组已安全保存，系统正在重启...");
        server->send(200, "text/html; charset=UTF-8", successHtml);
        
        delay(2000);  // 确保页面发送完成
        stopConfigPortal();
        delay(1000);
        esp_restart();
    } else {
        String errorHtml = generateErrorPage("保存失败", "无法保存设备配置，请重试。");
        server->send(500, "text/html; charset=UTF-8", errorHtml);
    }
}

void WebConfigManager::handleNotFound() {
    String errorHtml = generateErrorPage("页面未找到", "请求的页面不存在。");
    server->send(404, "text/html; charset=UTF-8", errorHtml);
}

String WebConfigManager::generateWiFiConfigPage() {
    return "<!DOCTYPE html><html><head><meta charset='UTF-8'><title>WiFi配网</title></head><body><h1>WiFi配网</h1><form action='/save' method='POST'>SSID: <input type='text' name='ssid'><br>Password: <input type='password' name='pass'><br><input type='submit' value='保存'></form></body></html>";
}

String WebConfigManager::generateSecureConfigPage() {
    return "<!DOCTYPE html><html><head><meta charset='UTF-8'><title>安全配置</title></head><body><h1>安全配置</h1><form action='/triset' method='POST'>密码: <input type='password' name='secret'><br>产品ID: <input type='text' name='product_id'><br>设备名称: <input type='text' name='device_name'><br>设备密钥: <input type='text' name='device_key'><br><input type='submit' value='保存'></form></body></html>";
}

String WebConfigManager::generateSuccessPage(const String& title, const String& message) {
    return "<!DOCTYPE html><html><head><meta charset='UTF-8'><title>" + title + "</title></head><body><h1>" + title + "</h1><p>" + message + "</p></body></html>";
}

String WebConfigManager::generateErrorPage(const String& title, const String& message) {
    return "<!DOCTYPE html><html><head><meta charset='UTF-8'><title>" + title + "</title></head><body><h1>" + title + "</h1><p>" + message + "</p><button onclick='history.back()'>返回</button></body></html>";
}