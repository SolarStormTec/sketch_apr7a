#ifndef WEB_CONFIG_MANAGER_H
#define WEB_CONFIG_MANAGER_H

#include <WiFi.h>
#include <WebServer.h>
#include <Preferences.h>
#include "esp_log.h"

/**
 * @brief Web配网管理器
 * 
 * 提供美观的Web界面用于：
 * 1. WiFi网络配置
 * 2. 设备三元组安全配置
 * 3. 系统状态显示
 */
class WebConfigManager {
public:
    WebConfigManager();
    ~WebConfigManager();
    
    /**
     * @brief 启动WiFi配网Portal
     * @param timeout_ms 超时时间(毫秒)
     * @param secure_mode 是否启用安全三元组配置模式
     * @return true 配置成功, false 超时或失败
     */
    bool startConfigPortal(uint32_t timeout_ms, bool secure_mode = false);
    
    /**
     * @brief 停止配网Portal
     */
    void stopConfigPortal();
    
    /**
     * @brief 检查是否有WiFi配置
     * @return true 有配置, false 无配置
     */
    bool hasWiFiConfig();
    
    /**
     * @brief 加载WiFi配置
     * @param ssid WiFi名称
     * @param password WiFi密码
     * @return true 加载成功, false 加载失败
     */
    bool loadWiFiConfig(String& ssid, String& password);
    
    /**
     * @brief 保存WiFi配置
     * @param ssid WiFi名称
     * @param password WiFi密码
     * @return true 保存成功, false 保存失败
     */
    bool saveWiFiConfig(const String& ssid, const String& password);
    
    /**
     * @brief 检查是否有设备三元组配置
     * @return true 有配置, false 无配置
     */
    bool hasDeviceConfig();
    
    /**
     * @brief 加载设备三元组配置
     * @param product_id 产品ID
     * @param device_name 设备名称
     * @param device_key 设备密钥
     * @return true 加载成功, false 加载失败
     */
    bool loadDeviceConfig(String& product_id, String& device_name, String& device_key);
    
    /**
     * @brief 保存设备三元组配置
     * @param product_id 产品ID
     * @param device_name 设备名称
     * @param device_key 设备密钥
     * @return true 保存成功, false 保存失败
     */
    bool saveDeviceConfig(const String& product_id, const String& device_name, const String& device_key);
    
    /**
     * @brief 验证设备三元组配置有效性
     * @param product_id 产品ID
     * @param device_name 设备名称
     * @param device_key 设备密钥
     * @return true 有效, false 无效
     */
    bool validateDeviceConfig(const String& product_id, const String& device_name, const String& device_key);

private:
    WebServer* server;
    bool portal_active;
    bool secure_mode;
    String ap_name;
    const String admin_password = "Tenkon123!@#";  // 管理员密码
    
    // Web页面处理函数
    void handleRoot();
    void handleSave();
    void handleSecureRoot();
    void handleSecureSave();
    void handleNotFound();
    
    // 工具函数
    String generateAPName();
    String generateWiFiConfigPage();
    String generateSecureConfigPage();
    String generateSuccessPage(const String& title, const String& message);
    String generateErrorPage(const String& title, const String& message);
    
    static const char* TAG;
};

#endif // WEB_CONFIG_MANAGER_H 