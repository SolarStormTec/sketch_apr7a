#ifndef INDUSTRIAL_STATS_H
#define INDUSTRIAL_STATS_H

#include <stdint.h>
#include "esp_err.h"
#include "esp_log.h"

/**
 * @brief 工业级统计数据结构（基于v1.0的IndustrialStats）
 */
typedef struct {
    // 发动机运行统计
    uint32_t engine_total_minutes;        // 累计运行分钟数
    uint32_t engine_start_count;          // 启动次数统计
    
    // 故障统计
    uint16_t oil_alarm_count;             // 油压报警次数
    uint16_t wifi_disconnect_count;       // WiFi断线次数
    uint16_t mqtt_failure_count;          // MQTT连接失败次数
    uint16_t memory_warning_count;        // 内存警告次数
    
    // 重启统计
    uint8_t restart_count_today;          // 今日重启次数
    uint32_t last_save_day;               // 上次保存的日期
    
    // 运行时统计
    uint32_t last_engine_start_time;      // 上次启动时间
    bool engine_was_running;              // 上次检查时发动机状态
    uint32_t last_stats_save_time;        // 上次保存统计数据时间
    
    // 维护相关
    uint16_t maintenance_interval_hours;  // 维护间隔小时数
    uint16_t rpm_alarm_threshold;         // 转速报警阈值
    
    // 性能统计
    uint32_t max_loop_time_ms;            // 最大循环时间
    uint32_t min_free_heap;               // 历史最小可用内存
    uint16_t watchdog_reset_count;        // 看门狗重启次数
} industrial_stats_t;

/**
 * @brief 事件类型枚举
 */
typedef enum {
    EVENT_ENGINE_START = 0,
    EVENT_ENGINE_STOP,
    EVENT_OIL_ALARM,
    EVENT_WIFI_DISCONNECT,
    EVENT_MQTT_FAILURE,
    EVENT_MEMORY_WARNING,
    EVENT_SYSTEM_RESTART,
    EVENT_MAINTENANCE_DUE,
    EVENT_OVERSPEED,
    EVENT_CRITICAL_ERROR,
    EVENT_TYPE_MAX
} industrial_event_type_t;

/**
 * @brief 工业级统计管理器类
 */
class IndustrialStatsManager {
public:
    IndustrialStatsManager();
    ~IndustrialStatsManager();
    
    /**
     * @brief 初始化统计管理器
     * @return ESP_OK 成功, 其他 失败
     */
    esp_err_t init();
    
    /**
     * @brief 加载统计数据
     * @return ESP_OK 成功, 其他 失败
     */
    esp_err_t load_stats();
    
    /**
     * @brief 保存统计数据
     * @return ESP_OK 成功, 其他 失败
     */
    esp_err_t save_stats();
    
    /**
     * @brief 更新发动机运行统计
     * @param is_running 发动机是否运行
     */
    void update_engine_stats(bool is_running);
    
    /**
     * @brief 记录事件
     * @param event_type 事件类型
     * @param value 事件值（可选）
     */
    void record_event(industrial_event_type_t event_type, uint32_t value = 0);
    
    /**
     * @brief 检查并上报工业级事件
     */
    void check_industrial_events();
    
    /**
     * @brief 获取统计数据
     * @return 统计数据指针
     */
    const industrial_stats_t* get_stats() const;
    
    /**
     * @brief 重置统计计数器
     * @param reset_totals 是否重置累计数据
     */
    void reset_counters(bool reset_totals = false);
    
    /**
     * @brief 重置发动机运行时间统计
     */
    void reset_engine_hours();
    
    /**
     * @brief 更新维护配置
     * @param maintenance_hours 维护间隔小时数
     * @param rpm_threshold 转速报警阈值
     */
    void update_maintenance_config(uint16_t maintenance_hours, uint16_t rpm_threshold);
    
    /**
     * @brief 检查是否需要维护
     * @return true 需要维护, false 不需要
     */
    bool is_maintenance_due() const;
    
    /**
     * @brief 获取运行时间（小时）
     * @return 发动机累计运行小时数
     */
    uint32_t get_engine_hours() const;
    
    /**
     * @brief 更新性能统计
     * @param loop_time_ms 循环时间
     * @param free_heap 可用内存
     */
    void update_performance_stats(uint32_t loop_time_ms, uint32_t free_heap);

private:
    industrial_stats_t stats_;
    bool initialized_;
    uint32_t last_check_time_;
    
    static const char* TAG;
    
    /**
     * @brief 获取当前日期（简化计算）
     * @return 当前日期数值
     */
    uint32_t get_current_day() const;
    
    /**
     * @brief 上报内存严重不足事件
     * @param free_bytes 可用字节数
     */
    void report_memory_critical_event(size_t free_bytes);
    
    /**
     * @brief 上报发动机超速事件
     * @param current_rpm 当前转速
     */
    void report_engine_overspeed_event(uint32_t current_rpm);
    
    /**
     * @brief 上报维护到期提醒
     */
    void report_maintenance_due_event();
    
    /**
     * @brief 上报频繁重启警报
     */
    void report_frequent_restart_event();
};

// 全局统计管理器实例
extern IndustrialStatsManager g_stats_manager;

#endif // INDUSTRIAL_STATS_H 