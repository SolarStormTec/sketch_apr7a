#include "industrial_stats.h"
#include "storage/preferences_manager.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

const char* IndustrialStatsManager::TAG = "IndustrialStats";

// 全局统计管理器实例
IndustrialStatsManager g_stats_manager;

IndustrialStatsManager::IndustrialStatsManager() : initialized_(false), last_check_time_(0) {
    // 初始化统计数据
    memset(&stats_, 0, sizeof(stats_));
    
    // 设置默认值
    stats_.maintenance_interval_hours = 200;
    stats_.rpm_alarm_threshold = 2200;
    stats_.min_free_heap = UINT32_MAX;
}

IndustrialStatsManager::~IndustrialStatsManager() {
    if (initialized_) {
        save_stats();
    }
}

esp_err_t IndustrialStatsManager::init() {
    if (initialized_) {
        ESP_LOGW(TAG, "工业统计管理器已初始化");
        return ESP_OK;
    }
    
    esp_err_t ret = load_stats();
    if (ret != ESP_OK) {
        ESP_LOGW(TAG, "加载统计数据失败，使用默认值");
    }
    
    initialized_ = true;
    last_check_time_ = pdTICKS_TO_MS(xTaskGetTickCount());
    
    ESP_LOGI(TAG, "工业统计管理器初始化完成");
    return ESP_OK;
}

esp_err_t IndustrialStatsManager::load_stats() {
    if (!g_prefs_mgr.read_uint32(NVS_NAMESPACE_STATS, "engine_min", &stats_.engine_total_minutes)) {
        stats_.engine_total_minutes = 0;
    }
    
    if (!g_prefs_mgr.read_uint32(NVS_NAMESPACE_STATS, "start_count", &stats_.engine_start_count)) {
        stats_.engine_start_count = 0;
    }
    
    stats_.oil_alarm_count = g_prefs_mgr.read_uint16(NVS_NAMESPACE_STATS, "oil_alarm", 0);
    stats_.wifi_disconnect_count = g_prefs_mgr.read_uint16(NVS_NAMESPACE_STATS, "wifi_disc", 0);
    stats_.mqtt_failure_count = g_prefs_mgr.read_uint16(NVS_NAMESPACE_STATS, "mqtt_fail", 0);
    stats_.memory_warning_count = g_prefs_mgr.read_uint16(NVS_NAMESPACE_STATS, "mem_warn", 0);
    stats_.restart_count_today = g_prefs_mgr.read_uint8(NVS_NAMESPACE_STATS, "restart_day", 0);
    stats_.last_save_day = g_prefs_mgr.read_uint32(NVS_NAMESPACE_STATS, "last_day", 0);
    
    ESP_LOGI(TAG, "统计数据加载完成: 运行%lu分钟, 启动%lu次", 
             stats_.engine_total_minutes, stats_.engine_start_count);
    
    return ESP_OK;
}

esp_err_t IndustrialStatsManager::save_stats() {
    if (!initialized_) {
        return ESP_ERR_INVALID_STATE;
    }
    
    // 防止频繁保存
    uint32_t now = pdTICKS_TO_MS(xTaskGetTickCount());
    if (now - stats_.last_stats_save_time < 10000) { // 10秒内只保存一次
        return ESP_OK;
    }
    
    bool success = true;
    success &= g_prefs_mgr.write_uint32(NVS_NAMESPACE_STATS, "engine_min", stats_.engine_total_minutes);
    success &= g_prefs_mgr.write_uint32(NVS_NAMESPACE_STATS, "start_count", stats_.engine_start_count);
    success &= g_prefs_mgr.write_uint16(NVS_NAMESPACE_STATS, "oil_alarm", stats_.oil_alarm_count);
    success &= g_prefs_mgr.write_uint16(NVS_NAMESPACE_STATS, "wifi_disc", stats_.wifi_disconnect_count);
    success &= g_prefs_mgr.write_uint16(NVS_NAMESPACE_STATS, "mqtt_fail", stats_.mqtt_failure_count);
    success &= g_prefs_mgr.write_uint16(NVS_NAMESPACE_STATS, "mem_warn", stats_.memory_warning_count);
    success &= g_prefs_mgr.write_uint8(NVS_NAMESPACE_STATS, "restart_day", stats_.restart_count_today);
    success &= g_prefs_mgr.write_uint32(NVS_NAMESPACE_STATS, "last_day", stats_.last_save_day);
    
    stats_.last_stats_save_time = now;
    
    if (success) {
        ESP_LOGD(TAG, "统计数据保存成功");
        return ESP_OK;
    } else {
        ESP_LOGE(TAG, "统计数据保存失败");
        return ESP_FAIL;
    }
}

void IndustrialStatsManager::update_engine_stats(bool is_running) {
    if (!initialized_) {
        return;
    }
    
    uint32_t now = pdTICKS_TO_MS(xTaskGetTickCount());
    
    // 每分钟检查一次
    if (now - last_check_time_ < 60000) {
        return;
    }
    last_check_time_ = now;
    
    // 检测启动事件
    if (is_running && !stats_.engine_was_running) {
        stats_.engine_start_count++;
        stats_.last_engine_start_time = now;
        ESP_LOGI(TAG, "发动机启动，累计启动次数: %lu", stats_.engine_start_count);
    }
    
    // 累计运行时间（按分钟）
    if (is_running) {
        stats_.engine_total_minutes++;
        
        // 每10分钟保存一次数据
        if (stats_.engine_total_minutes % 10 == 0) {
            save_stats();
        }
    }
    
    stats_.engine_was_running = is_running;
}

void IndustrialStatsManager::record_event(industrial_event_type_t event_type, uint32_t value) {
    if (!initialized_) {
        return;
    }
    
    switch (event_type) {
        case EVENT_ENGINE_START:
            stats_.engine_start_count++;
            break;
        case EVENT_OIL_ALARM:
            stats_.oil_alarm_count++;
            break;
        case EVENT_WIFI_DISCONNECT:
            stats_.wifi_disconnect_count++;
            break;
        case EVENT_MQTT_FAILURE:
            stats_.mqtt_failure_count++;
            break;
        case EVENT_MEMORY_WARNING:
            stats_.memory_warning_count++;
            break;
        case EVENT_SYSTEM_RESTART:
            stats_.restart_count_today++;
            break;
        default:
            break;
    }
    
    ESP_LOGD(TAG, "记录事件: %d, 值: %lu", event_type, value);
}

void IndustrialStatsManager::check_industrial_events() {
    // 简化实现，实际应该检查各种工业级事件
    // 这里只是占位符
}

const industrial_stats_t* IndustrialStatsManager::get_stats() const {
    return &stats_;
}

void IndustrialStatsManager::reset_counters(bool reset_totals) {
    if (reset_totals) {
        stats_.engine_total_minutes = 0;
        stats_.engine_start_count = 0;
    }
    
    stats_.oil_alarm_count = 0;
    stats_.wifi_disconnect_count = 0;
    stats_.mqtt_failure_count = 0;
    stats_.memory_warning_count = 0;
    stats_.restart_count_today = 0;
    
    save_stats();
    ESP_LOGI(TAG, "统计计数器已重置");
}

void IndustrialStatsManager::reset_engine_hours() {
    stats_.engine_total_minutes = 0;
    stats_.engine_start_count = 0;
    save_stats();
    ESP_LOGI(TAG, "发动机运行时间统计已重置");
}

void IndustrialStatsManager::update_maintenance_config(uint16_t maintenance_hours, uint16_t rpm_threshold) {
    stats_.maintenance_interval_hours = maintenance_hours;
    stats_.rpm_alarm_threshold = rpm_threshold;
    save_stats();
    ESP_LOGI(TAG, "维护配置已更新: %d小时, %d RPM", maintenance_hours, rpm_threshold);
}

bool IndustrialStatsManager::is_maintenance_due() const {
    uint32_t engine_hours = stats_.engine_total_minutes / 60;
    return engine_hours >= stats_.maintenance_interval_hours;
}

uint32_t IndustrialStatsManager::get_engine_hours() const {
    return stats_.engine_total_minutes / 60;
}

void IndustrialStatsManager::update_performance_stats(uint32_t loop_time_ms, uint32_t free_heap) {
    if (loop_time_ms > stats_.max_loop_time_ms) {
        stats_.max_loop_time_ms = loop_time_ms;
    }
    
    if (free_heap < stats_.min_free_heap) {
        stats_.min_free_heap = free_heap;
    }
}

uint32_t IndustrialStatsManager::get_current_day() const {
    return pdTICKS_TO_MS(xTaskGetTickCount()) / 86400000; // 简化的日期计算
}

void IndustrialStatsManager::report_memory_critical_event(size_t free_bytes) {
    ESP_LOGW(TAG, "内存严重不足: %d bytes", free_bytes);
    record_event(EVENT_MEMORY_WARNING);
}

void IndustrialStatsManager::report_engine_overspeed_event(uint32_t current_rpm) {
    ESP_LOGW(TAG, "发动机超速: %lu RPM", current_rpm);
    record_event(EVENT_OVERSPEED, current_rpm);
}

void IndustrialStatsManager::report_maintenance_due_event() {
    ESP_LOGW(TAG, "维护到期提醒: %lu 小时", get_engine_hours());
    record_event(EVENT_MAINTENANCE_DUE);
}

void IndustrialStatsManager::report_frequent_restart_event() {
    ESP_LOGW(TAG, "频繁重启警报: 今日%d次", stats_.restart_count_today);
} 