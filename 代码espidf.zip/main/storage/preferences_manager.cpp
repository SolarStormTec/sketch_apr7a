#include "preferences_manager.h"
#include "nvs_flash.h"
#include "esp_crc.h"

const char* PreferencesManager::TAG = "PreferencesManager";

// 命名空间名称映射
const char* PreferencesManager::namespace_names[NVS_NAMESPACE_MAX] = {
    "wifi",         // NVS_NAMESPACE_WIFI
    "device",       // NVS_NAMESPACE_DEVICE  
    "config",       // NVS_NAMESPACE_CONFIG
    "stats",        // NVS_NAMESPACE_STATS
    "ota",          // NVS_NAMESPACE_OTA
    "calibration",  // NVS_NAMESPACE_CALIBRATION
    "backup"        // NVS_NAMESPACE_BACKUP
};

// 全局实例
PreferencesManager g_prefs_mgr;

PreferencesManager::PreferencesManager() : initialized(false) {
    ESP_LOGI(TAG, "NVS存储管理器初始化");
}

PreferencesManager::~PreferencesManager() {
    // 析构函数
}

esp_err_t PreferencesManager::init() {
    if (initialized) {
        ESP_LOGW(TAG, "NVS存储管理器已初始化");
        return ESP_OK;
    }
    
    // 初始化NVS Flash
    esp_err_t ret = nvs_flash_init();
    if (ret == ESP_ERR_NVS_NO_FREE_PAGES || ret == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        ESP_LOGW(TAG, "NVS分区需要擦除，正在擦除...");
        ESP_ERROR_CHECK(nvs_flash_erase());
        ret = nvs_flash_init();
    }
    
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "NVS Flash初始化失败: %s", esp_err_to_name(ret));
        return ret;
    }
    
    initialized = true;
    ESP_LOGI(TAG, "NVS存储管理器初始化完成");
    
    // 验证所有命名空间的数据完整性
    for (int i = 0; i < NVS_NAMESPACE_MAX; i++) {
        esp_err_t verify_ret = verify_integrity((nvs_namespace_t)i);
        if (verify_ret != ESP_OK) {
            ESP_LOGW(TAG, "命名空间 %s 数据完整性验证失败，尝试恢复", namespace_names[i]);
            restore_namespace((nvs_namespace_t)i);
        }
    }
    
    return ESP_OK;
}

const char* PreferencesManager::get_namespace_name(nvs_namespace_t ns) {
    if (ns >= NVS_NAMESPACE_MAX) {
        return "unknown";
    }
    return namespace_names[ns];
}

esp_err_t PreferencesManager::read_value(nvs_namespace_t ns, const char* key, void* value, size_t size, nvs_data_type_t type) {
    if (!initialized || !key || !value) {
        return ESP_ERR_INVALID_ARG;
    }
    
    Preferences prefs;
    if (!prefs.begin(get_namespace_name(ns), true)) {
        ESP_LOGE(TAG, "无法打开命名空间: %s", get_namespace_name(ns));
        return ESP_FAIL;
    }
    
    esp_err_t ret = ESP_OK;
    
    switch (type) {
        case NVS_TYPE_UINT8:
            *(uint8_t*)value = prefs.getUChar(key, 0);
            break;
        case NVS_TYPE_UINT16:
            *(uint16_t*)value = prefs.getUShort(key, 0);
            break;
        case NVS_TYPE_UINT32:
            *(uint32_t*)value = prefs.getULong(key, 0);
            break;
        case NVS_TYPE_INT8:
            *(int8_t*)value = prefs.getChar(key, 0);
            break;
        case NVS_TYPE_INT16:
            *(int16_t*)value = prefs.getShort(key, 0);
            break;
        case NVS_TYPE_INT32:
            *(int32_t*)value = prefs.getInt(key, 0);
            break;
        case NVS_TYPE_FLOAT:
            *(float*)value = prefs.getFloat(key, 0.0f);
            break;
        case NVS_TYPE_DOUBLE:
            *(double*)value = prefs.getDouble(key, 0.0);
            break;
        case NVS_TYPE_BOOL:
            *(bool*)value = prefs.getBool(key, false);
            break;
        case NVS_TYPE_STRING: {
            String str = prefs.getString(key, "");
            strncpy((char*)value, str.c_str(), size - 1);
            ((char*)value)[size - 1] = '\0';
            break;
        }
        case NVS_TYPE_BLOB:
            if (prefs.getBytesLength(key) > size) {
                ret = ESP_ERR_INVALID_SIZE;
            } else {
                size_t actual_size = prefs.getBytes(key, value, size);
                if (actual_size == 0) {
                    ret = ESP_ERR_NVS_NOT_FOUND;
                }
            }
            break;
        default:
            ret = ESP_ERR_INVALID_ARG;
            break;
    }
    
    prefs.end();
    
    if (ret == ESP_OK) {
        ESP_LOGD(TAG, "读取 %s:%s 成功", get_namespace_name(ns), key);
    } else {
        ESP_LOGW(TAG, "读取 %s:%s 失败: %s", get_namespace_name(ns), key, esp_err_to_name(ret));
    }
    
    return ret;
}

esp_err_t PreferencesManager::write_value(nvs_namespace_t ns, const char* key, const void* value, size_t size, nvs_data_type_t type) {
    if (!initialized || !key || !value) {
        return ESP_ERR_INVALID_ARG;
    }
    
    Preferences prefs;
    if (!prefs.begin(get_namespace_name(ns), false)) {
        ESP_LOGE(TAG, "无法打开命名空间: %s", get_namespace_name(ns));
        return ESP_FAIL;
    }
    
    esp_err_t ret = ESP_OK;
    bool success = false;
    
    switch (type) {
        case NVS_TYPE_UINT8:
            success = prefs.putUChar(key, *(uint8_t*)value);
            break;
        case NVS_TYPE_UINT16:
            success = prefs.putUShort(key, *(uint16_t*)value);
            break;
        case NVS_TYPE_UINT32:
            success = prefs.putULong(key, *(uint32_t*)value);
            break;
        case NVS_TYPE_INT8:
            success = prefs.putChar(key, *(int8_t*)value);
            break;
        case NVS_TYPE_INT16:
            success = prefs.putShort(key, *(int16_t*)value);
            break;
        case NVS_TYPE_INT32:
            success = prefs.putInt(key, *(int32_t*)value);
            break;
        case NVS_TYPE_FLOAT:
            success = prefs.putFloat(key, *(float*)value);
            break;
        case NVS_TYPE_DOUBLE:
            success = prefs.putDouble(key, *(double*)value);
            break;
        case NVS_TYPE_BOOL:
            success = prefs.putBool(key, *(bool*)value);
            break;
        case NVS_TYPE_STRING:
            success = prefs.putString(key, (char*)value);
            break;
        case NVS_TYPE_BLOB:
            success = prefs.putBytes(key, value, size);
            break;
        default:
            ret = ESP_ERR_INVALID_ARG;
            break;
    }
    
    if (!success && ret == ESP_OK) {
        ret = ESP_FAIL;
    }
    
    prefs.end();
    
    if (ret == ESP_OK) {
        ESP_LOGD(TAG, "写入 %s:%s 成功", get_namespace_name(ns), key);
    } else {
        ESP_LOGE(TAG, "写入 %s:%s 失败: %s", get_namespace_name(ns), key, esp_err_to_name(ret));
    }
    
    return ret;
}

esp_err_t PreferencesManager::remove_key(nvs_namespace_t ns, const char* key) {
    if (!initialized || !key) {
        return ESP_ERR_INVALID_ARG;
    }
    
    Preferences prefs;
    if (!prefs.begin(get_namespace_name(ns), false)) {
        ESP_LOGE(TAG, "无法打开命名空间: %s", get_namespace_name(ns));
        return ESP_FAIL;
    }
    
    bool success = prefs.remove(key);
    prefs.end();
    
    if (success) {
        ESP_LOGI(TAG, "删除 %s:%s 成功", get_namespace_name(ns), key);
        return ESP_OK;
    } else {
        ESP_LOGW(TAG, "删除 %s:%s 失败", get_namespace_name(ns), key);
        return ESP_FAIL;
    }
}

esp_err_t PreferencesManager::clear_namespace(nvs_namespace_t ns) {
    if (!initialized) {
        return ESP_ERR_INVALID_STATE;
    }
    
    Preferences prefs;
    if (!prefs.begin(get_namespace_name(ns), false)) {
        ESP_LOGE(TAG, "无法打开命名空间: %s", get_namespace_name(ns));
        return ESP_FAIL;
    }
    
    bool success = prefs.clear();
    prefs.end();
    
    if (success) {
        ESP_LOGI(TAG, "清空命名空间 %s 成功", get_namespace_name(ns));
        return ESP_OK;
    } else {
        ESP_LOGE(TAG, "清空命名空间 %s 失败", get_namespace_name(ns));
        return ESP_FAIL;
    }
}

esp_err_t PreferencesManager::backup_namespace(nvs_namespace_t ns) {
    if (!initialized || ns == NVS_NAMESPACE_BACKUP) {
        return ESP_ERR_INVALID_ARG;
    }
    
    ESP_LOGI(TAG, "备份命名空间: %s", get_namespace_name(ns));
    
    // 这里简化实现，实际应该遍历所有键值对进行备份
    // 由于Preferences库限制，我们使用校验和验证方式
    
    return ESP_OK;
}

esp_err_t PreferencesManager::restore_namespace(nvs_namespace_t ns) {
    if (!initialized || ns == NVS_NAMESPACE_BACKUP) {
        return ESP_ERR_INVALID_ARG;
    }
    
    ESP_LOGI(TAG, "恢复命名空间: %s", get_namespace_name(ns));
    
    // 简化实现：清空损坏的数据
    return clear_namespace(ns);
}

esp_err_t PreferencesManager::verify_integrity(nvs_namespace_t ns) {
    if (!initialized) {
        return ESP_ERR_INVALID_STATE;
    }
    
    Preferences prefs;
    if (!prefs.begin(get_namespace_name(ns), true)) {
        // 如果无法打开命名空间，认为是正常的（可能还没有数据）
        return ESP_OK;
    }
    
    // 简化的完整性检查：检查是否有关键配置项
    bool has_data = false;
    
    switch (ns) {
        case NVS_NAMESPACE_WIFI:
            has_data = prefs.isKey("ssid");
            break;
        case NVS_NAMESPACE_DEVICE:
            has_data = prefs.isKey("product_id");
            break;
        case NVS_NAMESPACE_CONFIG:
            has_data = prefs.isKey("initialized");
            break;
        default:
            has_data = true; // 其他命名空间不验证
            break;
    }
    
    prefs.end();
    
    return ESP_OK; // 简化实现，总是返回OK
}

size_t PreferencesManager::get_used_entries(nvs_namespace_t ns) {
    if (!initialized) {
        return 0;
    }
    
    Preferences prefs;
    if (!prefs.begin(get_namespace_name(ns), true)) {
        return 0;
    }
    
    size_t used = prefs.freeEntries();
    prefs.end();
    
    return used;
}

uint32_t PreferencesManager::calculate_checksum(const void* data, size_t size) {
    return esp_crc32_le(0, (const uint8_t*)data, size);
}

String PreferencesManager::get_backup_key(const char* original_key) {
    return String("bak_") + original_key;
}

// 便捷接口实现
bool PreferencesManager::read_bool(nvs_namespace_t ns, const char* key, bool default_val) {
    bool value = default_val;
    esp_err_t ret = read_value(ns, key, &value, sizeof(value), NVS_TYPE_BOOL);
    return (ret == ESP_OK) ? value : default_val;
}

uint8_t PreferencesManager::read_uint8(nvs_namespace_t ns, const char* key, uint8_t default_val) {
    uint8_t value = default_val;
    esp_err_t ret = read_value(ns, key, &value, sizeof(value), NVS_TYPE_UINT8);
    return (ret == ESP_OK) ? value : default_val;
}

uint16_t PreferencesManager::read_uint16(nvs_namespace_t ns, const char* key, uint16_t default_val) {
    uint16_t value = default_val;
    esp_err_t ret = read_value(ns, key, &value, sizeof(value), NVS_TYPE_UINT16);
    return (ret == ESP_OK) ? value : default_val;
}

uint32_t PreferencesManager::read_uint32(nvs_namespace_t ns, const char* key, uint32_t default_val) {
    uint32_t value = default_val;
    esp_err_t ret = read_value(ns, key, &value, sizeof(value), NVS_TYPE_UINT32);
    return (ret == ESP_OK) ? value : default_val;
}

float PreferencesManager::read_float(nvs_namespace_t ns, const char* key, float default_val) {
    float value = default_val;
    esp_err_t ret = read_value(ns, key, &value, sizeof(value), NVS_TYPE_FLOAT);
    return (ret == ESP_OK) ? value : default_val;
}

String PreferencesManager::read_string(nvs_namespace_t ns, const char* key, const String& default_val) {
    char buffer[256];
    esp_err_t ret = read_value(ns, key, buffer, sizeof(buffer), NVS_TYPE_STRING);
    return (ret == ESP_OK) ? String(buffer) : default_val;
}

bool PreferencesManager::write_bool(nvs_namespace_t ns, const char* key, bool value) {
    return write_value(ns, key, &value, sizeof(value), NVS_TYPE_BOOL) == ESP_OK;
}

bool PreferencesManager::write_uint8(nvs_namespace_t ns, const char* key, uint8_t value) {
    return write_value(ns, key, &value, sizeof(value), NVS_TYPE_UINT8) == ESP_OK;
}

bool PreferencesManager::write_uint16(nvs_namespace_t ns, const char* key, uint16_t value) {
    return write_value(ns, key, &value, sizeof(value), NVS_TYPE_UINT16) == ESP_OK;
}

bool PreferencesManager::write_uint32(nvs_namespace_t ns, const char* key, uint32_t value) {
    return write_value(ns, key, &value, sizeof(value), NVS_TYPE_UINT32) == ESP_OK;
}

bool PreferencesManager::write_float(nvs_namespace_t ns, const char* key, float value) {
    return write_value(ns, key, &value, sizeof(value), NVS_TYPE_FLOAT) == ESP_OK;
}

bool PreferencesManager::write_string(nvs_namespace_t ns, const char* key, const String& value) {
    return write_value(ns, key, value.c_str(), value.length() + 1, NVS_TYPE_STRING) == ESP_OK;
} 