#ifndef PREFERENCES_MANAGER_H
#define PREFERENCES_MANAGER_H

#include <Preferences.h>
#include "esp_log.h"
#include "esp_err.h"

/**
 * @brief NVS命名空间定义
 */
typedef enum {
    NVS_NAMESPACE_WIFI = 0,      // WiFi配置
    NVS_NAMESPACE_DEVICE,        // 设备三元组
    NVS_NAMESPACE_CONFIG,        // 热配置参数
    NVS_NAMESPACE_STATS,         // 统计数据
    NVS_NAMESPACE_OTA,           // OTA配置
    NVS_NAMESPACE_CALIBRATION,   // 校准数据
    NVS_NAMESPACE_BACKUP,        // 数据备份
    NVS_NAMESPACE_MAX
} nvs_namespace_t;

/**
 * @brief 数据类型枚举
 */
typedef enum {
    NVS_TYPE_UINT8 = 0,
    NVS_TYPE_UINT16,
    NVS_TYPE_UINT32,
    NVS_TYPE_INT8,
    NVS_TYPE_INT16,
    NVS_TYPE_INT32,
    NVS_TYPE_FLOAT,
    NVS_TYPE_DOUBLE,
    NVS_TYPE_BOOL,
    NVS_TYPE_STRING,
    NVS_TYPE_BLOB
} nvs_data_type_t;

/**
 * @brief 配置项结构体
 */
typedef struct {
    const char* key;           // 键名
    nvs_data_type_t type;      // 数据类型
    const void* default_value; // 默认值
    size_t max_size;           // 最大尺寸（用于字符串和blob）
} nvs_config_item_t;

/**
 * @brief NVS存储管理器类
 */
class PreferencesManager {
public:
    PreferencesManager();
    ~PreferencesManager();
    
    /**
     * @brief 初始化NVS存储
     * @return ESP_OK 成功, 其他 失败
     */
    esp_err_t init();
    
    /**
     * @brief 读取配置值
     * @param ns 命名空间
     * @param key 键名
     * @param value 输出值
     * @param size 值大小
     * @param type 数据类型
     * @return ESP_OK 成功, 其他 失败
     */
    esp_err_t read_value(nvs_namespace_t ns, const char* key, void* value, size_t size, nvs_data_type_t type);
    
    /**
     * @brief 写入配置值
     * @param ns 命名空间
     * @param key 键名
     * @param value 输入值
     * @param size 值大小
     * @param type 数据类型
     * @return ESP_OK 成功, 其他 失败
     */
    esp_err_t write_value(nvs_namespace_t ns, const char* key, const void* value, size_t size, nvs_data_type_t type);
    
    /**
     * @brief 删除配置值
     * @param ns 命名空间
     * @param key 键名
     * @return ESP_OK 成功, 其他 失败
     */
    esp_err_t remove_key(nvs_namespace_t ns, const char* key);
    
    /**
     * @brief 清空命名空间
     * @param ns 命名空间
     * @return ESP_OK 成功, 其他 失败
     */
    esp_err_t clear_namespace(nvs_namespace_t ns);
    
    /**
     * @brief 备份配置数据
     * @param ns 要备份的命名空间
     * @return ESP_OK 成功, 其他 失败
     */
    esp_err_t backup_namespace(nvs_namespace_t ns);
    
    /**
     * @brief 从备份恢复配置数据
     * @param ns 要恢复的命名空间
     * @return ESP_OK 成功, 其他 失败
     */
    esp_err_t restore_namespace(nvs_namespace_t ns);
    
    /**
     * @brief 验证数据完整性
     * @param ns 命名空间
     * @return ESP_OK 完整, 其他 损坏
     */
    esp_err_t verify_integrity(nvs_namespace_t ns);
    
    /**
     * @brief 获取命名空间使用的存储空间
     * @param ns 命名空间
     * @return 使用的字节数
     */
    size_t get_used_entries(nvs_namespace_t ns);
    
    // 便捷接口
    bool read_bool(nvs_namespace_t ns, const char* key, bool default_val = false);
    uint8_t read_uint8(nvs_namespace_t ns, const char* key, uint8_t default_val = 0);
    uint16_t read_uint16(nvs_namespace_t ns, const char* key, uint16_t default_val = 0);
    uint32_t read_uint32(nvs_namespace_t ns, const char* key, uint32_t default_val = 0);
    float read_float(nvs_namespace_t ns, const char* key, float default_val = 0.0f);
    String read_string(nvs_namespace_t ns, const char* key, const String& default_val = "");
    
    bool write_bool(nvs_namespace_t ns, const char* key, bool value);
    bool write_uint8(nvs_namespace_t ns, const char* key, uint8_t value);
    bool write_uint16(nvs_namespace_t ns, const char* key, uint16_t value);
    bool write_uint32(nvs_namespace_t ns, const char* key, uint32_t value);
    bool write_float(nvs_namespace_t ns, const char* key, float value);
    bool write_string(nvs_namespace_t ns, const char* key, const String& value);

private:
    /**
     * @brief 获取命名空间名称
     * @param ns 命名空间枚举
     * @return 命名空间字符串
     */
    const char* get_namespace_name(nvs_namespace_t ns);
    
    /**
     * @brief 生成备份键名
     * @param original_key 原始键名
     * @return 备份键名
     */
    String get_backup_key(const char* original_key);
    
    /**
     * @brief 计算数据校验和
     * @param data 数据指针
     * @param size 数据大小
     * @return 校验和
     */
    uint32_t calculate_checksum(const void* data, size_t size);
    
    static const char* TAG;
    static const char* namespace_names[NVS_NAMESPACE_MAX];
    bool initialized;
};

// 全局实例
extern PreferencesManager g_prefs_mgr;

#endif // PREFERENCES_MANAGER_H 