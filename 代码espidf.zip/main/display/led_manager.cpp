#include "led_manager.h"
#include "driver/gpio.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_log.h"

const char* LEDManager::TAG = "LEDManager";

// LED模式配置表（基于v1.0的精确配置）
const led_pattern_t LEDManager::led_patterns_[LED_MODE_MAX] = {
    {0,     0,   0,   0},    // LED_MODE_OFF - 全关
    {600,   50,  50,  50},   // LED_MODE_INIT_BLINK - 红绿交替闪烁(慢)
    {200,   50,  50,  0},    // LED_MODE_CONFIG_PORTAL - 红绿同时快闪
    {1000,  0,   30,  0},    // LED_MODE_WIFI_CONNECTING - 绿灯慢闪
    {300,   0,   50,  0},    // LED_MODE_MQTT_CONNECTING - 绿灯快闪
    {0,     0,   100, 0},    // LED_MODE_ENGINE_RUNNING - 绿灯常亮
    {0,     100, 0,   0},    // LED_MODE_ENGINE_STOPPED - 红灯常亮
    {2000,  30,  0,   0},    // LED_MODE_OFFLINE - 红灯慢闪
    {150,   80,  0,   0},    // LED_MODE_OIL_ALARM - 红灯极快闪
    {800,   50,  50,  0},    // LED_MODE_OTA_UPDATE - 红绿同时慢闪
    {400,   33,  0,   0},    // LED_MODE_SYSTEM_ERROR - 红灯三连闪效果
    {250,   50,  50,  50},   // LED_MODE_LOW_MEMORY - 红绿交替快闪
    {600,   0,   40,  0},    // LED_MODE_WEAK_SIGNAL - 绿灯双闪效果
    {500,   40,  0,   0},    // LED_MODE_TOKEN_ERROR - 红灯双闪效果
};

// 全局LED管理器实例
LEDManager g_led_manager;

LEDManager::LEDManager() : current_mode_(LED_MODE_OFF), last_update_time_(0), 
                          led_cycle_(0), initialized_(false) {
    config_.red_pin = -1;
    config_.green_pin = -1;
    config_.invert_logic = false;
}

LEDManager::~LEDManager() {
    if (initialized_) {
        set_leds(false, false);
    }
}

esp_err_t LEDManager::init(const led_config_t& config) {
    if (initialized_) {
        ESP_LOGW(TAG, "LED管理器已初始化");
        return ESP_OK;
    }
    
    config_ = config;
    
    // 验证引脚配置
    if (config_.red_pin < 0 || config_.green_pin < 0) {
        ESP_LOGE(TAG, "无效的LED引脚配置: red=%d, green=%d", config_.red_pin, config_.green_pin);
        return ESP_ERR_INVALID_ARG;
    }
    
    // 配置GPIO
    gpio_config_t io_conf = {};
    io_conf.intr_type = GPIO_INTR_DISABLE;
    io_conf.mode = GPIO_MODE_OUTPUT;
    io_conf.pin_bit_mask = (1ULL << config_.red_pin) | (1ULL << config_.green_pin);
    io_conf.pull_down_en = GPIO_PULLDOWN_DISABLE;
    io_conf.pull_up_en = GPIO_PULLUP_DISABLE;
    
    esp_err_t ret = gpio_config(&io_conf);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "GPIO配置失败: %s", esp_err_to_name(ret));
        return ret;
    }
    
    // 初始化为关闭状态
    set_leds(false, false);
    
    initialized_ = true;
    ESP_LOGI(TAG, "LED管理器初始化完成: red_pin=%d, green_pin=%d, invert=%s", 
             config_.red_pin, config_.green_pin, config_.invert_logic ? "true" : "false");
    
    return ESP_OK;
}

void LEDManager::set_mode(led_mode_t mode) {
    if (mode >= LED_MODE_MAX) {
        ESP_LOGW(TAG, "无效的LED模式: %d", mode);
        return;
    }
    
    if (current_mode_ != mode) {
        ESP_LOGI(TAG, "LED模式切换: %s -> %s", 
                 get_mode_description(current_mode_), get_mode_description(mode));
        current_mode_ = mode;
        led_cycle_ = 0;
        last_update_time_ = pdTICKS_TO_MS(xTaskGetTickCount());
    }
}

led_mode_t LEDManager::get_current_mode() const {
    return current_mode_;
}

void LEDManager::update() {
    if (!initialized_) {
        return;
    }
    
    uint32_t current_time = pdTICKS_TO_MS(xTaskGetTickCount());
    execute_led_control(current_time);
}

void LEDManager::set_leds(bool red_on, bool green_on) {
    if (!initialized_) {
        return;
    }
    
    // 根据逻辑反转设置
    uint32_t red_level = config_.invert_logic ? !red_on : red_on;
    uint32_t green_level = config_.invert_logic ? !green_on : green_on;
    
    gpio_set_level((gpio_num_t)config_.red_pin, red_level);
    gpio_set_level((gpio_num_t)config_.green_pin, green_level);
}

const char* LEDManager::get_mode_description(led_mode_t mode) {
    static const char* descriptions[LED_MODE_MAX] = {
        "关闭",           // LED_MODE_OFF
        "初始化闪烁",     // LED_MODE_INIT_BLINK
        "配网模式",       // LED_MODE_CONFIG_PORTAL
        "WiFi连接中",     // LED_MODE_WIFI_CONNECTING
        "MQTT连接中",     // LED_MODE_MQTT_CONNECTING
        "发动机运行",     // LED_MODE_ENGINE_RUNNING
        "发动机停止",     // LED_MODE_ENGINE_STOPPED
        "网络离线",       // LED_MODE_OFFLINE
        "机油报警",       // LED_MODE_OIL_ALARM
        "OTA升级",        // LED_MODE_OTA_UPDATE
        "系统错误",       // LED_MODE_SYSTEM_ERROR
        "内存不足",       // LED_MODE_LOW_MEMORY
        "信号弱",         // LED_MODE_WEAK_SIGNAL
        "认证错误"        // LED_MODE_TOKEN_ERROR
    };
    
    if (mode >= LED_MODE_MAX) {
        return "未知";
    }
    
    return descriptions[mode];
}

void LEDManager::execute_led_control(uint32_t current_time) {
    if (current_mode_ >= LED_MODE_MAX) {
        return;
    }
    
    const led_pattern_t& pattern = led_patterns_[current_mode_];
    
    // 常亮模式处理
    if (pattern.period == 0) {
        bool red = (pattern.red_on_time > 0);
        bool green = (pattern.green_on_time > 0);
        set_leds(red, green);
        return;
    }
    
    // 闪烁模式处理
    if (current_time - last_update_time_ >= pattern.period) {
        last_update_time_ = current_time;
        led_cycle_ = (led_cycle_ + 1) % 100; // 0-99的循环计数
    }
    
    uint32_t elapsed = current_time - last_update_time_;
    uint8_t position = (elapsed * 100) / pattern.period; // 当前在周期中的位置(0-99)
    
    // 计算红灯状态
    bool red_on = false;
    if (pattern.red_on_time > 0) {
        if (pattern.phase_shift == 0) {
            // 同相闪烁
            red_on = (position < pattern.red_on_time);
        } else {
            // 交替闪烁
            uint8_t red_position = (position + pattern.phase_shift) % 100;
            red_on = (red_position < pattern.red_on_time);
        }
    }
    
    // 计算绿灯状态
    bool green_on = false;
    if (pattern.green_on_time > 0) {
        green_on = (position < pattern.green_on_time);
    }
    
    set_leds(red_on, green_on);
} 