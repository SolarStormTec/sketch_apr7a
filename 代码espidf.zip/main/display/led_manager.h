#ifndef LED_MANAGER_H
#define LED_MANAGER_H

#include <stdint.h>
#include "esp_err.h"

/**
 * @brief LED模式定义（基于v1.0的LED状态指示系统）
 */
typedef enum {
    LED_MODE_OFF = 0,                    // 全部关闭 - 系统未启动
    LED_MODE_INIT_BLINK,                 // 红绿交替闪烁 - 系统初始化
    LED_MODE_CONFIG_PORTAL,              // 红绿同时快闪 - 配网模式
    LED_MODE_WIFI_CONNECTING,            // 绿灯慢闪 - WiFi连接中
    LED_MODE_MQTT_CONNECTING,            // 绿灯快闪 - MQTT连接中
    LED_MODE_ENGINE_RUNNING,             // 绿灯常亮 - 发动机运行+在线
    LED_MODE_ENGINE_STOPPED,             // 红灯常亮 - 发动机停止+在线
    LED_MODE_OFFLINE,                    // 红灯慢闪 - 网络离线
    LED_MODE_OIL_ALARM,                  // 红灯极快闪 - 机油报警
    LED_MODE_OTA_UPDATE,                 // 红绿同时慢闪 - OTA升级
    LED_MODE_SYSTEM_ERROR,               // 红灯三连闪 - 系统错误
    LED_MODE_LOW_MEMORY,                 // 红绿交替快闪 - 内存不足
    LED_MODE_WEAK_SIGNAL,                // 绿灯双闪 - 信号弱
    LED_MODE_TOKEN_ERROR,                // 红灯双闪 - 认证错误
    LED_MODE_MAX
} led_mode_t;

/**
 * @brief LED模式配置结构体
 */
typedef struct {
    uint16_t period;          // 周期(ms)
    uint8_t red_on_time;      // 红灯亮时间比例(0-100)
    uint8_t green_on_time;    // 绿灯亮时间比例(0-100)
    uint8_t phase_shift;      // 相位差(0-100)，用于交替闪烁
} led_pattern_t;

/**
 * @brief LED管理器配置
 */
typedef struct {
    int red_pin;              // 红色LED引脚
    int green_pin;            // 绿色LED引脚
    bool invert_logic;        // 是否反转逻辑（共阳极）
} led_config_t;

/**
 * @brief LED状态管理器类
 */
class LEDManager {
public:
    LEDManager();
    ~LEDManager();
    
    /**
     * @brief 初始化LED管理器
     * @param config LED配置
     * @return ESP_OK 成功, 其他 失败
     */
    esp_err_t init(const led_config_t& config);
    
    /**
     * @brief 设置LED模式
     * @param mode LED模式
     */
    void set_mode(led_mode_t mode);
    
    /**
     * @brief 获取当前LED模式
     * @return 当前LED模式
     */
    led_mode_t get_current_mode() const;
    
    /**
     * @brief 更新LED显示（需要周期性调用）
     */
    void update();
    
    /**
     * @brief 直接控制LED状态
     * @param red_on 红灯是否点亮
     * @param green_on 绿灯是否点亮
     */
    void set_leds(bool red_on, bool green_on);
    
    /**
     * @brief 获取LED模式描述
     * @param mode LED模式
     * @return 模式描述字符串
     */
    static const char* get_mode_description(led_mode_t mode);

private:
    led_config_t config_;
    led_mode_t current_mode_;
    uint32_t last_update_time_;
    uint8_t led_cycle_;
    bool initialized_;
    
    static const led_pattern_t led_patterns_[LED_MODE_MAX];
    static const char* TAG;
    
    /**
     * @brief 执行LED控制逻辑
     * @param current_time 当前时间
     */
    void execute_led_control(uint32_t current_time);
};

// 全局LED管理器实例
extern LEDManager g_led_manager;

#endif // LED_MANAGER_H 