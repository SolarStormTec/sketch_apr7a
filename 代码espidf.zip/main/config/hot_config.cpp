#include "hot_config.h"
#include "storage/preferences_manager.h"
#include "cJSON.h"

const char* HotConfigManager::TAG = "HotConfig";

// 全局热配置管理器实例
HotConfigManager g_hot_config;

HotConfigManager::HotConfigManager() : config_version_(1), initialized_(false), update_callback_(nullptr) {
    init_default_config();
    config_ = default_config_;
}

HotConfigManager::~HotConfigManager() {
    if (initialized_) {
        save_config();
    }
}

esp_err_t HotConfigManager::init() {
    if (initialized_) {
        ESP_LOGW(TAG, "热配置管理器已初始化");
        return ESP_OK;
    }
    
    esp_err_t ret = load_config();
    if (ret != ESP_OK) {
        ESP_LOGW(TAG, "加载配置失败，使用默认配置");
        config_ = default_config_;
    }
    
    initialized_ = true;
    ESP_LOGI(TAG, "热配置管理器初始化完成");
    
    return ESP_OK;
}

void HotConfigManager::init_default_config() {
    // 初始化默认配置（基于v1.0的默认值）
    default_config_.engine_start_pull_low_time = 7000;
    default_config_.engine_start_wait_time = 3000;
    default_config_.engine_stop_pull_low_time = 2000;
    default_config_.engine_stop_wait_time = 3000;
    default_config_.rpm_calibration = 1.0f;
    default_config_.engine_on_rpm_threshold = 1800;
    default_config_.wake_pulse_ms = 100;
    default_config_.wake_to_long_ms = 300;
    
    // 新增字段默认值
    default_config_.device_status = false;
    default_config_.rpm_alarm_threshold = 2200;
    default_config_.maintenance_interval_hours = 200;
    default_config_.wifi_rssi_weak_threshold = -75;
    default_config_.memory_warning_threshold = 20480;
    default_config_.ota_check_interval_minutes = 60;
    
    // 系统控制参数
    default_config_.auto_update = true;
    default_config_.report_interval_ms = 1500;
    default_config_.heartbeat_interval_s = 600;
    default_config_.log_level = 3; // ESP_LOG_INFO
    
    // 网络参数
    default_config_.mqtt_keep_alive_s = 600;
    default_config_.wifi_reconnect_delay_s = 10;
    default_config_.max_retry_count = 3;
    
    // 安全参数
    default_config_.enable_watchdog = true;
    default_config_.watchdog_timeout_ms = 8000;
    default_config_.enable_stack_protection = true;
    default_config_.stack_warning_threshold = 2048;
}

esp_err_t HotConfigManager::load_config() {
    // 使用Preferences管理器加载配置
    config_.engine_start_pull_low_time = g_prefs_mgr.read_uint32(NVS_NAMESPACE_CONFIG, "start_low", default_config_.engine_start_pull_low_time);
    config_.engine_start_wait_time = g_prefs_mgr.read_uint32(NVS_NAMESPACE_CONFIG, "start_wait", default_config_.engine_start_wait_time);
    config_.engine_stop_pull_low_time = g_prefs_mgr.read_uint32(NVS_NAMESPACE_CONFIG, "stop_low", default_config_.engine_stop_pull_low_time);
    config_.engine_stop_wait_time = g_prefs_mgr.read_uint32(NVS_NAMESPACE_CONFIG, "stop_wait", default_config_.engine_stop_wait_time);
    config_.rpm_calibration = g_prefs_mgr.read_float(NVS_NAMESPACE_CONFIG, "rpm_calib", default_config_.rpm_calibration);
    config_.engine_on_rpm_threshold = g_prefs_mgr.read_uint16(NVS_NAMESPACE_CONFIG, "rpm_thres", default_config_.engine_on_rpm_threshold);
    config_.wake_pulse_ms = g_prefs_mgr.read_uint32(NVS_NAMESPACE_CONFIG, "wake_pulse", default_config_.wake_pulse_ms);
    config_.wake_to_long_ms = g_prefs_mgr.read_uint32(NVS_NAMESPACE_CONFIG, "wake_long", default_config_.wake_to_long_ms);
    
    config_.device_status = g_prefs_mgr.read_bool(NVS_NAMESPACE_CONFIG, "dev_status", default_config_.device_status);
    config_.rpm_alarm_threshold = g_prefs_mgr.read_uint16(NVS_NAMESPACE_CONFIG, "rpm_alarm", default_config_.rpm_alarm_threshold);
    config_.maintenance_interval_hours = g_prefs_mgr.read_uint16(NVS_NAMESPACE_CONFIG, "maint_hours", default_config_.maintenance_interval_hours);
    config_.wifi_rssi_weak_threshold = (int16_t)g_prefs_mgr.read_uint16(NVS_NAMESPACE_CONFIG, "wifi_weak", (uint16_t)default_config_.wifi_rssi_weak_threshold);
    config_.memory_warning_threshold = g_prefs_mgr.read_uint32(NVS_NAMESPACE_CONFIG, "mem_warn", default_config_.memory_warning_threshold);
    config_.ota_check_interval_minutes = g_prefs_mgr.read_uint16(NVS_NAMESPACE_CONFIG, "ota_interval", default_config_.ota_check_interval_minutes);
    
    config_.auto_update = g_prefs_mgr.read_bool(NVS_NAMESPACE_CONFIG, "auto_update", default_config_.auto_update);
    config_.report_interval_ms = g_prefs_mgr.read_uint16(NVS_NAMESPACE_CONFIG, "report_int", default_config_.report_interval_ms);
    
    ESP_LOGI(TAG, "热配置加载完成");
    return ESP_OK;
}

esp_err_t HotConfigManager::save_config() {
    if (!initialized_) {
        return ESP_ERR_INVALID_STATE;
    }
    
    bool success = true;
    success &= g_prefs_mgr.write_uint32(NVS_NAMESPACE_CONFIG, "start_low", config_.engine_start_pull_low_time);
    success &= g_prefs_mgr.write_uint32(NVS_NAMESPACE_CONFIG, "start_wait", config_.engine_start_wait_time);
    success &= g_prefs_mgr.write_uint32(NVS_NAMESPACE_CONFIG, "stop_low", config_.engine_stop_pull_low_time);
    success &= g_prefs_mgr.write_uint32(NVS_NAMESPACE_CONFIG, "stop_wait", config_.engine_stop_wait_time);
    success &= g_prefs_mgr.write_float(NVS_NAMESPACE_CONFIG, "rpm_calib", config_.rpm_calibration);
    success &= g_prefs_mgr.write_uint16(NVS_NAMESPACE_CONFIG, "rpm_thres", config_.engine_on_rpm_threshold);
    success &= g_prefs_mgr.write_uint32(NVS_NAMESPACE_CONFIG, "wake_pulse", config_.wake_pulse_ms);
    success &= g_prefs_mgr.write_uint32(NVS_NAMESPACE_CONFIG, "wake_long", config_.wake_to_long_ms);
    
    success &= g_prefs_mgr.write_bool(NVS_NAMESPACE_CONFIG, "dev_status", config_.device_status);
    success &= g_prefs_mgr.write_uint16(NVS_NAMESPACE_CONFIG, "rpm_alarm", config_.rpm_alarm_threshold);
    success &= g_prefs_mgr.write_uint16(NVS_NAMESPACE_CONFIG, "maint_hours", config_.maintenance_interval_hours);
    success &= g_prefs_mgr.write_uint16(NVS_NAMESPACE_CONFIG, "wifi_weak", (uint16_t)config_.wifi_rssi_weak_threshold);
    success &= g_prefs_mgr.write_uint32(NVS_NAMESPACE_CONFIG, "mem_warn", config_.memory_warning_threshold);
    success &= g_prefs_mgr.write_uint16(NVS_NAMESPACE_CONFIG, "ota_interval", config_.ota_check_interval_minutes);
    
    success &= g_prefs_mgr.write_bool(NVS_NAMESPACE_CONFIG, "auto_update", config_.auto_update);
    success &= g_prefs_mgr.write_uint16(NVS_NAMESPACE_CONFIG, "report_int", config_.report_interval_ms);
    
    if (success) {
        ESP_LOGD(TAG, "热配置保存成功");
        return ESP_OK;
    } else {
        ESP_LOGE(TAG, "热配置保存失败");
        return ESP_FAIL;
    }
}

const hot_config_t* HotConfigManager::get_config() const {
    return &config_;
}

esp_err_t HotConfigManager::update_config(const hot_config_t& new_config, bool save_immediately) {
    if (!initialized_) {
        return ESP_ERR_INVALID_STATE;
    }
    
    if (!validate_config(new_config)) {
        ESP_LOGE(TAG, "配置验证失败");
        return ESP_ERR_INVALID_ARG;
    }
    
    hot_config_t old_config = config_;
    config_ = new_config;
    config_version_++;
    
    if (save_immediately) {
        esp_err_t ret = save_config();
        if (ret != ESP_OK) {
            // 恢复旧配置
            config_ = old_config;
            config_version_--;
            return ret;
        }
    }
    
    trigger_update_callback(&old_config);
    ESP_LOGI(TAG, "配置已更新，版本: %lu", config_version_);
    
    return ESP_OK;
}

esp_err_t HotConfigManager::reset_to_defaults() {
    ESP_LOGI(TAG, "重置为默认配置");
    
    hot_config_t old_config = config_;
    config_ = default_config_;
    config_version_++;
    
    esp_err_t ret = save_config();
    if (ret == ESP_OK) {
        trigger_update_callback(&old_config);
    }
    
    return ret;
}

bool HotConfigManager::validate_config(const hot_config_t& config) const {
    // 基本范围检查
    if (config.engine_start_pull_low_time < 1000 || config.engine_start_pull_low_time > 10000) {
        return false;
    }
    
    if (config.rpm_calibration < 0.1f || config.rpm_calibration > 10.0f) {
        return false;
    }
    
    if (config.engine_on_rpm_threshold > 5000) {
        return false;
    }
    
    if (config.rpm_alarm_threshold < 1000 || config.rpm_alarm_threshold > 4000) {
        return false;
    }
    
    if (config.maintenance_interval_hours < 10 || config.maintenance_interval_hours > 2000) {
        return false;
    }
    
    return true;
}

esp_err_t HotConfigManager::register_update_callback(config_update_callback_t callback) {
    update_callback_ = callback;
    ESP_LOGI(TAG, "配置更新回调已注册");
    return ESP_OK;
}

void HotConfigManager::trigger_update_callback(const hot_config_t* old_config) {
    if (update_callback_) {
        update_callback_(old_config, &config_);
    }
}

uint32_t HotConfigManager::get_config_version() const {
    return config_version_;
}

esp_err_t HotConfigManager::update_from_json(const char* json_str) {
    // 简化实现，实际应该解析JSON并更新配置
    ESP_LOGW(TAG, "JSON配置更新功能尚未完全实现");
    return ESP_ERR_NOT_SUPPORTED;
}

esp_err_t HotConfigManager::export_to_json(char* json_buffer, size_t buffer_size) const {
    // 简化实现，实际应该导出完整的JSON配置
    int len = snprintf(json_buffer, buffer_size, 
        "{\"device_status\":%s,\"rpm_threshold\":%d,\"auto_update\":%s}",
        config_.device_status ? "true" : "false",
        config_.engine_on_rpm_threshold,
        config_.auto_update ? "true" : "false");
    
    if (len >= buffer_size) {
        return ESP_ERR_INVALID_SIZE;
    }
    
    return ESP_OK;
} 