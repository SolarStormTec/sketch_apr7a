#ifndef HOT_CONFIG_H
#define HOT_CONFIG_H

#include <stdint.h>
#include "esp_err.h"
#include "esp_log.h"

/**
 * @brief 热配置数据结构（基于v1.0的HotConfig）
 */
typedef struct {
    // 原有引擎控制参数
    uint32_t engine_start_pull_low_time;    // 启动拉低时间
    uint32_t engine_start_wait_time;        // 启动等待时间
    uint32_t engine_stop_pull_low_time;     // 停止拉低时间
    uint32_t engine_stop_wait_time;         // 停止等待时间
    float rpm_calibration;                  // RPM校准系数
    uint16_t engine_on_rpm_threshold;       // 发动机启动RPM阈值
    uint32_t wake_pulse_ms;                 // 唤醒脉冲时间
    uint32_t wake_to_long_ms;               // 唤醒到长按时间
    
    // 关键热配置参数
    bool device_status;                     // 设备开关状态
    uint16_t rpm_alarm_threshold;           // 转速报警阈值
    uint16_t maintenance_interval_hours;    // 维护间隔小时数
    int16_t wifi_rssi_weak_threshold;       // WiFi弱信号阈值
    uint32_t memory_warning_threshold;      // 内存警告阈值(字节)
    uint16_t ota_check_interval_minutes;    // OTA检查间隔(分钟)
    
    // 系统控制参数
    bool auto_update;                       // 自动更新开关
    uint16_t report_interval_ms;            // 数据上报间隔
    uint16_t heartbeat_interval_s;          // 心跳间隔
    uint8_t log_level;                      // 日志级别
    
    // 网络参数
    uint16_t mqtt_keep_alive_s;             // MQTT保活时间
    uint16_t wifi_reconnect_delay_s;        // WiFi重连延时
    uint8_t max_retry_count;                // 最大重试次数
    
    // 安全参数
    bool enable_watchdog;                   // 启用看门狗
    uint32_t watchdog_timeout_ms;           // 看门狗超时时间
    bool enable_stack_protection;          // 启用栈保护
    uint32_t stack_warning_threshold;       // 栈警告阈值
} hot_config_t;

/**
 * @brief 配置更新回调函数类型
 */
typedef void (*config_update_callback_t)(const hot_config_t* old_config, const hot_config_t* new_config);

/**
 * @brief 热配置管理器类
 */
class HotConfigManager {
public:
    HotConfigManager();
    ~HotConfigManager();
    
    /**
     * @brief 初始化热配置管理器
     * @return ESP_OK 成功, 其他 失败
     */
    esp_err_t init();
    
    /**
     * @brief 加载热配置
     * @return ESP_OK 成功, 其他 失败
     */
    esp_err_t load_config();
    
    /**
     * @brief 保存热配置
     * @return ESP_OK 成功, 其他 失败
     */
    esp_err_t save_config();
    
    /**
     * @brief 获取当前配置
     * @return 配置指针
     */
    const hot_config_t* get_config() const;
    
    /**
     * @brief 更新配置参数
     * @param new_config 新配置
     * @param save_immediately 是否立即保存
     * @return ESP_OK 成功, 其他 失败
     */
    esp_err_t update_config(const hot_config_t& new_config, bool save_immediately = true);
    
    /**
     * @brief 部分更新配置
     * @param key 配置键名
     * @param value 配置值
     * @param save_immediately 是否立即保存
     * @return ESP_OK 成功, 其他 失败
     */
    esp_err_t update_config_value(const char* key, const void* value, size_t value_size, bool save_immediately = true);
    
    /**
     * @brief 重置为默认配置
     * @return ESP_OK 成功, 其他 失败
     */
    esp_err_t reset_to_defaults();
    
    /**
     * @brief 验证配置有效性
     * @param config 要验证的配置
     * @return true 有效, false 无效
     */
    bool validate_config(const hot_config_t& config) const;
    
    /**
     * @brief 注册配置更新回调
     * @param callback 回调函数
     * @return ESP_OK 成功, 其他 失败
     */
    esp_err_t register_update_callback(config_update_callback_t callback);
    
    /**
     * @brief 从JSON字符串更新配置
     * @param json_str JSON字符串
     * @return ESP_OK 成功, 其他 失败
     */
    esp_err_t update_from_json(const char* json_str);
    
    /**
     * @brief 导出配置为JSON字符串
     * @param json_buffer 输出缓冲区
     * @param buffer_size 缓冲区大小
     * @return ESP_OK 成功, 其他 失败
     */
    esp_err_t export_to_json(char* json_buffer, size_t buffer_size) const;
    
    /**
     * @brief 获取配置版本号
     * @return 配置版本号
     */
    uint32_t get_config_version() const;

private:
    hot_config_t config_;
    hot_config_t default_config_;
    uint32_t config_version_;
    bool initialized_;
    config_update_callback_t update_callback_;
    
    static const char* TAG;
    
    /**
     * @brief 初始化默认配置
     */
    void init_default_config();
    
    /**
     * @brief 触发配置更新回调
     * @param old_config 旧配置
     */
    void trigger_update_callback(const hot_config_t* old_config);
    
    /**
     * @brief 从NVS加载单个配置项
     * @param key 键名
     * @param value 值指针
     * @param size 值大小
     * @param default_value 默认值
     * @return ESP_OK 成功, 其他 失败
     */
    esp_err_t load_config_item(const char* key, void* value, size_t size, const void* default_value);
    
    /**
     * @brief 保存单个配置项到NVS
     * @param key 键名
     * @param value 值指针
     * @param size 值大小
     * @return ESP_OK 成功, 其他 失败
     */
    esp_err_t save_config_item(const char* key, const void* value, size_t size);
};

// 全局热配置管理器实例
extern HotConfigManager g_hot_config;

// 便捷宏定义用于访问配置
#define GET_CONFIG() (g_hot_config.get_config())
#define GET_ENGINE_START_TIME() (g_hot_config.get_config()->engine_start_pull_low_time)
#define GET_ENGINE_STOP_TIME() (g_hot_config.get_config()->engine_stop_pull_low_time)
#define GET_RPM_THRESHOLD() (g_hot_config.get_config()->engine_on_rpm_threshold)
#define GET_DEVICE_STATUS() (g_hot_config.get_config()->device_status)
#define GET_RPM_ALARM_THRESHOLD() (g_hot_config.get_config()->rpm_alarm_threshold)

#endif // HOT_CONFIG_H 